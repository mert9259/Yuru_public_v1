Programın çalışması için server.js dosyası main dosyadır onu çalıştırmanız gerekmekte.
Ayrıca postman uygulamasından veriyi json olarak göndermelisiniz. Göndereceğiniz json verinin formatı user.json şeklinde tekli kayıt olmalıdır.
Veritabanı kayıt işleminin gerçekleştirilmesi için yuru_app adında bir veritabanının içine users tablosu oluşturulmalıdır.